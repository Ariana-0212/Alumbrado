// --- Configuración de Pines ---
const int LDR_SOLAR_PIN = A0;             // Sensor de luz ambiental
const int LED_POSTES[] = {2, 3, 4, 5, 6}; // Pines Digitales para encender los LEDs
const int LDR_POSTES[] = {A1, A2, A3, A4, A5}; // Pines Analógicos para medir luz de cada LED
const int NUM_POSTES = 5;

// --- Umbral ---
const int UMBRAL_NOCHE = 30; // 30% de luz solar para activar el sistema

void setup() {
  Serial.begin(9600);
  
  // Configurar pines de los LEDs como salida
  for (int i = 0; i < NUM_POSTES; i++) {
    pinMode(LED_POSTES[i], OUTPUT);
  }
  
  Serial.println("SISTEMA DE ILUMINAClON INTELIGENTE INICIADO");
  Serial.println("--------------------------------------------");
}

void loop() {
  // 1. Leer LDR Solar y convertir a porcentaje
  int lecturaSolar = analogRead(LDR_SOLAR_PIN);
  int porcSolar = map(lecturaSolar, 0, 1023, 0, 100);

  // 2. Lógica del Sistema (Se activa si hay menos del 30% de luz solar)
  bool sistemaActivo = (porcSolar < UMBRAL_NOCHE);

  Serial.println(">>> REPORTE DE ESTADO <<<");
  Serial.print("Luz Solar: "); Serial.print(porcSolar); Serial.println("%");
  Serial.print("Estado Sistema: "); Serial.println(sistemaActivo ? "ENCENDIDO (Noche)" : "APAGADO (Dia)");
  Serial.println("-------------------------");

  for (int i = 0; i < NUM_POSTES; i++) {
    // Controlar el LED del poste
    if (sistemaActivo) {
      digitalWrite(LED_POSTES[i], HIGH);
    } else {
      digitalWrite(LED_POSTES[i], LOW);
    }

    // Leer el LDR individual del poste y convertir a porcentaje
    int lecturaPoste = analogRead(LDR_POSTES[i]);
    int porcPoste = map(lecturaPoste, 0, 1023, 0, 100);
    
    // 3. Detección de Falla
    // Si el sistema es de noche (sistemaActivo) pero el LDR del LED marca poca luz (falla)
    String statusPoste = "OK";
    if (sistemaActivo && porcPoste < 20) { // Umbral de 20% para detectar si el LED realmente brilla
      statusPoste = "!!! FALLA (LED Fundido o bloqueado) !!!";
    }

    // 5. Mostrar en Monitor Serial
    Serial.print("Poste #"); Serial.print(i + 1);
    Serial.print(" | LED: "); Serial.print(sistemaActivo ? "ON " : "OFF");
    Serial.print(" | Luz LED: "); Serial.print(porcPoste); Serial.print("%");
    Serial.print(" | "); Serial.println(statusPoste);
  }

  Serial.println("=========================\n");
  delay(3000); // Pausa de 3 segundos para facilitar la lectura
}
